package com.docmall.domain;

import lombok.Data;

@Data
public class LoginDTO {
	
	private String mem_id;
	private String mem_pw;

}
