package com.docmall.domain;

import lombok.Data;

@Data
public class CategoryVO {

	// cate_code_pk, cate_code_prt, cate_name
	
	private Integer cate_code_pk;
	private Integer cate_code_prt;
	private String cate_name;
}
