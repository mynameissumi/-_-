package com.docmall.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.docmall.domain.AdminVO;
import com.docmall.mapper.AdminMapper;

import lombok.Setter;

@Service // adminServiceImpl bean 생성
public class AdminServiceImpl implements AdminService {

	@Setter(onMethod_ = @Autowired)  // Setter메서드를 통한 주입
	private AdminMapper mapper;
	
	@Override
	public AdminVO adminLogin(AdminVO vo) {
		// TODO Auto-generated method stub
		return mapper.adminLogin(vo);
	}

	@Override
	public void loginTimeUpdate(AdminVO vo) {
		// TODO Auto-generated method stub
		mapper.loginTimeUpdate(vo);
	}

	@Override
	public void changePW(AdminVO vo, String changePw) {
		// TODO Auto-generated method stub
		mapper.changePW(vo, changePw);
	}

}
