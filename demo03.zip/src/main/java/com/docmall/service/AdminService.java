package com.docmall.service;

import org.apache.ibatis.annotations.Param;

import com.docmall.domain.AdminVO;

public interface AdminService {

	public AdminVO adminLogin(AdminVO vo);
	
	public void loginTimeUpdate(AdminVO vo);
	
	public void changePW(AdminVO vo, String changePw);
}
