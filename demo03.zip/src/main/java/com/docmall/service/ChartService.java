package com.docmall.service;

import java.util.List;

import com.docmall.domain.StatChartVO;

public interface ChartService {

	public List<StatChartVO> getYearSales();
}
