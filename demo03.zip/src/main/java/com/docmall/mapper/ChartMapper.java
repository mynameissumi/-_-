package com.docmall.mapper;

import java.util.List;

import com.docmall.domain.StatChartVO;

public interface ChartMapper {

	public List<StatChartVO> getYearSales();
}
