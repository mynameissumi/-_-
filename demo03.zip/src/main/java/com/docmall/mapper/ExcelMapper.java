package com.docmall.mapper;

import java.util.List;

import com.docmall.domain.ProductVO;

public interface ExcelMapper {

	public List<ProductVO> getProductExcel();
}
